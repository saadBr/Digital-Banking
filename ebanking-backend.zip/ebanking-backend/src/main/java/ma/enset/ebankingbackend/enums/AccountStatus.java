package ma.enset.ebankingbackend.enums;

public enum AccountStatus {
    CREATED,
    SUSPENDED,
    ACTIVATED
}
